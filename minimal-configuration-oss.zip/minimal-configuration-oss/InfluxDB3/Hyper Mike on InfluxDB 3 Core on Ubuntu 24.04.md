# InfluxDB 3 Core on Ubuntu 24.04

> Note: `InfluxDB 3 Core` is now in `beta`. The syntax to install is the same as `alpha` if you already used that one previously.

## Overview

In the next steps we will install `InfluxDB3 Core` on `Ubuntu 24.04`.
Also, we will create and populate a test database that we will name
`mydb`.

Many steps are exactly like the official `InfluxDB` examples, including
the first sample code to paste in to get started.

Then we look at using the commandline or APIs to look at your data.

## Supporting Links

For the official vendor guidance see [https://docs.influxdata.com/influxdb3/core/get-started/](https://docs.influxdata.com/influxdb3/core/get-started/).


## Install `curl` if needed

    sudo apt install curl

## Install `InfluxDB3 Core`

    curl -O https://www.influxdata.com/d/install_influxdb3.sh && sh install_influxdb3.sh

## Refresh your `~/.bashrc`

Make the path available now, instead of having to log off/on again.

    source ~/.bashrc

## Show version

    influxdb3 --version

## Optionally show the path

    which influxdb3

## Optional - install `tmux`

This will be helpful if you do not have it.
In future steps we will run `InfluxDB3 Core` and it will run interactively on your console.
By having `tmux` you can split your screen easily.

    #install tmux
    sudo apt install tmux

    #launch tmux
    tmux

    #split screen horizontally
    CTRL+b %

    #split screen vertically
    CTRL+b "

    #exit a tmux window (or tmux itself on the last window)
    exit

    #close tmux but keep in the background
    tmux detach

    #later relaunch your tmux session
    tmux attach

> Note: You can even exit your terminal completely and attach later, you just cannot log off and reattach after login)

## Using the `influxdb3` binary

To start an interactive runtime of `InfluxDB Core` we can use the same
binary that we were checking the version with, `influxdb3`.

    #get help about starting with "serve"
    influxdb3 serve --help

    #get all help
    influxdb3 --help | more

## Start the interactive process (only for "alpha" or "beta" releases)

The final version will run automatically as a service hopefully.
For now it must be run manually after you login.

    influxdb3 serve --node-id=local01 --object-store=memory

> Note: This only runs in memory but iis perfect to query data and practice. Eventually, you can point to real storage, if desired.

## Show your port usage

Optionally use something like `netstat` to see that port `8181` is now being used by `InfluxDB`.

    netstat -ano | grep 8181

## Show information

We currently have nothing setup, but we will come back to this command.

    influxdb3 show databases

## Create a database

    influxdb3 create database mydb

## Show databases again

    influxdb3 show databases

## Populate the database

This uses the official example from the InfluxData guide at [https://docs.influxdata.com/influxdb3/core/get-started/](https://docs.influxdata.com/influxdb3/core/get-started/)

Here we add some example information to act as pseudo data for testing. Later we will query this data.

    influxdb3 write \
    --database mydb\
    --token "beta" \
    'home,room=Living\ Room temp=21.1,hum=35.9,co=0i 1740038400
    home,room=Kitchen temp=21.0,hum=35.9,co=0i 1740038400
    home,room=Living\ Room temp=21.4,hum=35.9,co=0i 1740042000
    home,room=Kitchen temp=23.0,hum=36.2,co=0i 1740042000
    home,room=Living\ Room temp=21.8,hum=36.0,co=0i 1740045600
    home,room=Kitchen temp=22.7,hum=36.1,co=0i 1740045600
    home,room=Living\ Room temp=22.2,hum=36.0,co=0i 1740049200
    home,room=Kitchen temp=22.4,hum=36.0,co=0i 1740049200
    home,room=Living\ Room temp=22.2,hum=35.9,co=0i 1740052800
    home,room=Kitchen temp=22.5,hum=36.0,co=0i 1740052800
    home,room=Living\ Room temp=22.4,hum=36.0,co=0i 1740056400
    home,room=Kitchen temp=22.8,hum=36.5,co=1i 1740056400'


## Query the data

Although the backend is doing magical things as you would expect
from the `InfluxData` team, the actual default query language
for `InfluxDB3 Core` is `SQL`.

    influxdb3 query --database mydb "SELECT * FROM home"

> Note: We can also use all api styles from `InfluxDB` versions 1 and 2.

## Run a "legacy" query against `InfluxDB3 Core`

When using the legacy `InfluxQL`, which totally works fine, we can
choose from `DATABASES`, `FIELD`, `MEASUREMENTS`, `TAG`, or
`RETENTION`. Here we will query `MEASUREMENTS`.

    influxdb3 query --database=mydb --language=influxql "SHOW MEASUREMENTS"

## API Endpoints

We can use various endpoints as desired for `http` API access.

    # These are the official endpoints
    http://localhost:8181/api/v3/query_sql
    http://localhost:8181/api/v3/query_influxql

    # These also work, but prefer the above
    http://localhost:8181/health
    http://localhost:8181/query


## Example checking health of `InfluxDB3 Core` using legacy syntax

    # using legacy style
    $url = "http://localhost:8181/health"
    Invoke-RestMethod -Uri $url

## using modern style
   
#$url = "http://localhost:8181/api/v3/query_sql"
$token = "beta" | ConvertTo-SecureString -AsPlainText -Force
$Body = @{
    db = "mydb"
    q = "SHOW TABLES"
}
$report = Invoke-RestMethod -Uri $url -Token $token -Body $Body

## example outpupt

    PS /home/stats> $report                                                        

    table_catalog table_schema       table_name                 table_type
    ------------- ------------       ----------                 ----------
    public        iox                processes                  BASE TABLE
    public        iox                mem                        BASE TABLE
    public        iox                nstat                      BASE TABLE
    public        iox                disk                       BASE TABLE
    public        iox                system                     BASE TABLE
    public        iox                kernel                     BASE TABLE
    public        iox                cpu                        BASE TABLE
    public        iox                diskio                     BASE TABLE
    public        iox                swap                       BASE TABLE
    public        iox                net                        BASE TABLE
    public        iox                home                       BASE TABLE
    public        system             distinct_caches            BASE TABLE
    public        system             last_caches                BASE TABLE
    public        system             parquet_files              BASE TABLE
    public        system             processing_engine_logs     BASE TABLE
    public        system             processing_engine_triggers BASE TABLE
    public        system             queries                    BASE TABLE
    public        information_schema tables                     VIEW
    public        information_schema views                      VIEW
    public        information_schema columns                    VIEW
    public        information_schema df_settings                VIEW
    public        information_schema schemata                   VIEW


## Get recent cpu

    $url = "http://localhost:8181/api/v3/query_sql"
    $token = "beta" | ConvertTo-SecureString -AsPlainText -Force
    $Body = @{
        db = "mydb"
        q = "SELECT * FROM cpu LIMIT 5"
    }
    $report = Invoke-RestMethod -Uri $url -Token $token -Body $Body

## Get recent memory

    $url = "http://localhost:8181/api/v3/query_sql"
    $token = "beta" | ConvertTo-SecureString -AsPlainText -Force
    $Body = @{
        db = "mydb"
        q = "SELECT * FROM mem LIMIT 5"
    }
    $report = Invoke-RestMethod -Uri $url -Token $token -Body $Body

    #look at first entry
    $report[0]


## Customize property names

Here we are still looking at only one entry by indexing into the array with [0].
We then rename the output of some properties for style or clarity.
    
    $report[0] | select host,@{n='memory_used_percent';  e={$_.used_percent}},@{n='timestamp (UTC)'; e={$_.time}},@{n='timestamp (local)'; e={(Get-Date -Date $_.time).ToLocalTime()}}

## Show recent

Same command as above, but we remove the [0] so we see all 5 recents in our report

    $report | select host,@{n='memory_used_percent'; e={$_.used_percent}},@{n='timestamp (UTC)'; e={$_.time}},@{n='timestamp (local)'; e={(Get-Date -Date $_.time).ToLocalTime()}}

> Note: We only see 5 entries because we set the "Limit" to 5 in the `Body` when creating the report variable earlier.


## PowerShell Example

# InfluxDB3 Core, beta
$url = "http://localhost:8181/api/v3/query_sql"
$token = "beta" | ConvertTo-SecureString -AsPlainText -Force
$Body = @{
    db = "mydb"
    q = "SHOW TABLES"
}
$report = Invoke-RestMethod -Uri $url -Token $token -Body $Body

## Viewing the InfluxDB internal stats

These seem to be the internal health like /debug/vars from InfluxDB version 1.


    $report.Where{$_.'table_schema' -eq 'system' }


## example output

    table_catalog table_schema table_name                 table_type
    ------------- ------------ ----------                 ----------
    public        system       distinct_caches            BASE TABLE
    public        system       last_caches                BASE TABLE
    public        system       parquet_files              BASE TABLE
    public        system       processing_engine_logs     BASE TABLE
    public        system       processing_engine_triggers BASE TABLE
    public        system       queries                    BASE TABLE

> Note: The layout for InfluxDB3 Core (beta) is different and does not seem to have feature partiy yet with the previous `OSS` internal stats. For example, to popualate `metrics velocity` from the very bottom of the `Grafana` dashboard for `InfluxDB and Telegraf` (dashboard `928`). However, that bottom part of the dashboard will not work for now (at least with the current beta version of InfluxDB3 Core).

## Regular CLI example

Here we look further at one of the system tables called "queries"

    influxdb3 query --database=mydb "SELECT * FROM system.queries LIMIT 2"

## More internal beta

    influxdb3 query --database=mydb "SHOW COLUMNS in system.queries"

### Example output

```

    stats@stats02:~$ influxdb3 query --database=mydb "SHOW COLUMNS in system.queries"
    +---------------+--------------+------------+------------------+-----------------------------+-------------+
    | table_catalog | table_schema | table_name | column_name      | data_type                   | is_nullable |
    +---------------+--------------+------------+------------------+-----------------------------+-------------+
    | public        | system       | queries    | id               | Utf8                        | NO          |
    | public        | system       | queries    | phase            | Utf8                        | NO          |
    | public        | system       | queries    | issue_time       | Timestamp(Nanosecond, None) | NO          |
    | public        | system       | queries    | query_type       | Utf8                        | NO          |
    | public        | system       | queries    | query_text       | Utf8                        | NO          |
    | public        | system       | queries    | partitions       | Int64                       | YES         |
    | public        | system       | queries    | parquet_files    | Int64                       | YES         |
    | public        | system       | queries    | plan_duration    | Duration(Nanosecond)        | YES         |
    | public        | system       | queries    | permit_duration  | Duration(Nanosecond)        | YES         |
    | public        | system       | queries    | execute_duration | Duration(Nanosecond)        | YES         |
    | public        | system       | queries    | end2end_duration | Duration(Nanosecond)        | YES         |
    | public        | system       | queries    | compute_duration | Duration(Nanosecond)        | YES         |
    | public        | system       | queries    | max_memory       | Int64                       | YES         |
    | public        | system       | queries    | success          | Boolean                     | NO          |
    | public        | system       | queries    | running          | Boolean                     | NO          |
    | public        | system       | queries    | cancelled        | Boolean                     | NO          |
    | public        | system       | queries    | trace_id         | Utf8                        | YES         |
    +---------------+--------------+------------+------------------+-----------------------------+-------------+

```

## Not to be confused with

    influxdb3 query --database=mydb "SELECT * FROM system LIMIT 2"

### Example output

    stats@stats02:~$ influxdb3 query --database=mydb "SELECT * FROM system LIMIT 2"
    +---------+-------+--------+-------+--------+----------------+---------+---------------------+--------+---------------+
    | host    | load1 | load15 | load5 | n_cpus | n_unique_users | n_users | time                | uptime | uptime_format |
    +---------+-------+--------+-------+--------+----------------+---------+---------------------+--------+---------------+
    | stats02 | 0.82  | 0.52   | 0.69  | 4      | 1              | 2       | 2025-02-28T20:37:50 | 19190  |  5:19         |
    | stats02 | 0.7   | 0.51   | 0.66  | 4      | 1              | 2       | 2025-02-28T20:38:00 | 19200  |  5:20         |
    +---------+-------+--------+-------+--------+----------------+---------+---------------------+--------+---------------+


## Connecting to a remote endpoint

This requires that port `8181` has already been opened on the remote node, allow it to communicate with our machine.

> tip: You can use `arp -a` to see ip addresses on your local subnet.


echo "line 1"
echo "line 2"

## http example

    $url = 'http://192.168.122.175:8181/api/v3/query_sql'
    $token = "someString" | ConvertTo-SecureString -AsPlainText -Force
    $Body = @{ db = "mydb"; q = "SHOW TABLES"}
    $report = Invoke-RestMethod -Uri $url -Token $token -Body $Body
    $report


## https example for self-signed certs

    $url = 'https://192.168.122.175:8181/api/v3/query_sql';
    $token = "someString" | ConvertTo-SecureString -AsPlainText -Force;
    $Body = @{ db = "mydb"; q = "SHOW TABLES"};
    $report = Invoke-RestMethod -Uri $url -Token $token -Body $Body -SkipCertificateCheck;
    $report

