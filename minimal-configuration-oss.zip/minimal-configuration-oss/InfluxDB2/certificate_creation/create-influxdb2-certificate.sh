#!/bin/bash

## This script creates a certificate with "SAN" information, which
## is perfect for InfluxDB2, if you want https and self-signed
## certificates. Please note that self-signed certificates
## are not for production.  You can get a real CA from
## your infosec team or by buying one. Here we create
## something good enough for an isolated lab.
##
## The SAN information is needed for modern certificates,
## even self-signed. Specifically, you cannot use the
## official InfluxDB 1 documentation to create self-
## signed certs for InfluxDB2.
##
## Here we follow the official InfluxDB 2 instructions,
## except we add an additional key usage of 'digitalSignature', 
## which is case sensitive. Adding this allows access from modern
## browsers such as chrome, etc. This is useful for reaching the web
## interface.  Without this additional key usage, everything would work fine
## except for access to the web interface, for example at "https://localhost:8086".

# to run this script:
#
#  chmod +x ./create-influxdb2-certificate.sh
#
# then run from bash
#  sudo create-influxdb2-certificate.sh
#
# Or, run from powershell
#   sudo ./create-influxdb2-certificate.sh

## See the official guide for this topic at:
## https://docs.influxdata.com/influxdb/v2/admin/security/enable-tls/


###########
## main
###########

cat > san.cnf <<EOF
   [req]
   distinguished_name = req_distinguished_name
   req_extensions = v3_req
   prompt = no

   [req_distinguished_name]
   C = US
   ST = Illinois
   L = Chicagp
   O = Hyper Mike Labs
   OU = IT Department
   CN = stats03

   [v3_req]
   keyUsage = keyEncipherment, dataEncipherment, digitalSignature
   extendedKeyUsage = serverAuth
   subjectAltName = @alt_names

   [alt_names]
   DNS.1 = localhost
   DNS.2 = stats03
   IP.1 = 192.168.122.226
EOF

# Generate a private key and certificate signing request (CSR)
# using the configuration file 
openssl req -new -newkey rsa:2048 -nodes \
  -keyout /etc/ssl/influxdb-selfsigned.key \
  -out /etc/ssl/influxdb-selfsigned.csr \
  -config san.cnf

# Generate the self-signed certificate
openssl x509 -req -in /etc/ssl/influxdb-selfsigned.csr \
  -signkey /etc/ssl/influxdb-selfsigned.key \
  -out /etc/ssl/influxdb-selfsigned.crt \
  -days 365 \
  -extensions v3_req -extfile san.cnf

# Remove the temporary configuration file
rm san.cnf
