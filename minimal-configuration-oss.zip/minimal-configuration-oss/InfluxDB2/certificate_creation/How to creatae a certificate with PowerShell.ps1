# How to creatae a certificate with PowerShell.ps1

# example from google AI
#
# The InfluxDB2 instructions for creating a cert with SAN is not
# strong enough for modern browsers, and you might get:
#
#   #example error
#   ERR_SSL_KEY_USAGE_INCOMPATIBLE 
#

## Work-around
##
## Create with powershell or similar and include the required key usage setting of "DigitalSignature".
New-SelfSignedCertificate -DnsName "yourdomain.local" -CertStoreLocation "Cert:\CurrentUser\My" -KeyUsage DigitalSignature

